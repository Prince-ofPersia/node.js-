var http = require('http');
res.end(`
<!DOCTYPE html>
<html>
<title>welcome saviour</title>
<HEAD>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
    body, h1, h2, h3, h4, h5 {
        font-family: "Raleway", sans-serif
    }
</style>

<script> 
function validation()                                    
{ 
    var name = document.forms["RegForm"]["n"];               
    var email = document.forms["RegForm"]["e"];    
    var phone = document.forms["RegForm"]["m"];  
   
   
    if (name.value == "")                                  
    { 
        window.alert("Please enter your name."); 
        name.focus(); 
        return false; 
    } 
         
    if (email.value == "")                                   
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
   
    if (email.value.indexOf("@", 0) < 0)                 
    { 
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	if (reg.test(emailField.value) == false)
        {
        alert('Invalid Email Address');
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
   
    if (email.value.indexOf(".", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
   
    if (phone.value == "")                           
    { 
	var val = m.value
	if (/^\d{10}$/.test(val)) {
    // value is ok, use it
	} else {
   	 alert("Invalid number; must be ten digits")
  	  number.focus()
	    return false
}
        window.alert("Please enter your telephone number."); 
        phone.focus(); 
        return false; 
    } 
   
   
   
    return true; 
}</script> 
</HEAD>
<BODY>
 <div class="w3-card w3-margin"
  <div class="w3-container w3-padding">
     <h4>Sign up</h4>
          </div>
            <div class="w3-container w3-white">
                
			 <form action="/app.js" method="post" onsubmit="return validation()>
                           

   				 <p>Your Name Saviour:<input type="text" name="n" required> </p><br>        
    
 			         <p>E-mail: <input type="text" name="e" required>  </p><br> 
     
    				 <p>phone: <input type="text"  name="m" required> </p><br>   

			         <input type = "submit" name = "submit" value = "Submit" />
                                 <input type = "reset" name = "reset"  value = "Reset" />

                        </form>
                    </div>
                </div>
</BODY>
</HTML>
      `);
    if (req.method === 'POST') {

    collectRequestData(req, result => {
        var mysql = require('mysql');

        var con = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "password",
            database: "EXPERIMENT"
        });

        con.connect(function (err) {
            if (err) throw err;
            console.log("Connected!");
            var sql = "INSERT INTO SignUp (NAME,EMAIL,NUM) VALUES ('n', 'e','m')";
            con.query(sql, function (err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            });
        });
    });

    